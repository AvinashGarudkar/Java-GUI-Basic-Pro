import java.awt.*;
import javax.swing.*;
class EX
{
	public static void main(String args[])
	{
		JFrame frame=new JFrame();
		frame.setVisible(true);
		frame.setBounds(400,150,500,250);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon icon=new ImageIcon("icon.PNG");
		frame.setIconImage(icon.getImage());
		frame.setTitle("Demo Application");

		Container c=frame.getContentPane();
		c.setLayout(null);
				
		JLabel label=new JLabel("WELCOME");
		label.setBounds(160,10,400,30);
		Font f=new Font("Algerian",Font.ITALIC,30);
		label.setFont(f);
		label.setForeground(Color.YELLOW);
		c.add(label);
		
		ImageIcon iuser=new ImageIcon("user.PNG");
		JLabel userimg=new JLabel(iuser);
		userimg.setBounds(60,58,iuser.getIconWidth(),iuser.getIconHeight());
		c.add(userimg);
		
		JLabel uname=new JLabel("User Name :");
		uname.setBounds(100,60,200,30);
		Font fu=new Font("Arial",Font.BOLD,20);
		uname.setFont(fu);
		Color clrt=new  Color(255,10,60);
		uname.setForeground(clrt);
		c.add(uname);
		
		JTextField utext=new JTextField();
		utext.setBounds(225,60,200,30);
		Color clr1=new  Color(255,230,230);
		utext.setBackground(clr1);
		c.add(utext);
				
		ImageIcon ipass=new ImageIcon("password.PNG");
		JLabel passimg=new JLabel(ipass);
		passimg.setBounds(60,108,ipass.getIconWidth(),ipass.getIconHeight());
		c.add(passimg);
		
		JLabel pass=new JLabel("Password :");
		pass.setBounds(100,110,200,30);
		Font fp=new Font("Aria",Font.BOLD,20);
		pass.setFont(fp);
		pass.setForeground(clrt);
		c.add(pass);
		
		JPasswordField ptext=new JPasswordField();
		ptext.setBounds(225,110,200,30);
		ptext.setBackground(clr1);
		c.add(ptext);
		
		JButton btn=new JButton("Log In");
		btn.setBounds(100,160,100,30);
		Color clr2=new Color(255,9,132);
		btn.setBackground(clr2);
		btn.setForeground(Color.white);
		c.add(btn);
		
		JButton btn2=new JButton("Register");
		btn2.setBounds(270,160,100,30);
		Color clr3=new Color(255,105,85);
		btn2.setBackground(clr3);
		btn2.setForeground(Color.white);
		c.add(btn2);
		
		Color clr=new Color(0,172,237);
		c.setBackground(clr);
	}
}
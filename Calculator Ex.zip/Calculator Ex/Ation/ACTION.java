import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
class ACTION
{
	static JFrame frame=new JFrame();
	static Container cont=frame.getContentPane();
	static JTextField text=new JTextField();	
	static JButton btn=new JButton("Submit");
	static JLabel text2=new JLabel("HI");
	static int ans;
	public static void main(String args[])
	{
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(500,100,300,350);
		frame.setVisible(true);
		cont.setLayout(null);
		
		text.setBounds(50,10,100,30);
		cont.add(text);
		
		btn.setBounds(50,50,100,30);
		btn.addActionListener(new My());
		cont.add(btn);
		
		text2.setBounds(50,100,100,30);
		text2.setText(ans);
		cont.add(text2);
		
		
	}

	public static class My implements ActionListener
	{
		public void actionPerformed(ActionEvent e)
		{
			int name=Integer.parseInt(text.getText());					
			ans=name+name;
			
		}
	}
}
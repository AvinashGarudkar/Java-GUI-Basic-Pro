import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class FRAME extends JFrame
{
	JFrame frame=new JFrame();
	Container c=frame.getContentPane();
	Font font=new Font("Arial",Font.BOLD,15);
	JLabel lebfont=new JLabel("Font");
	String arrfonts[]=new String[]{"Arial","Algerian","Harrington"};
	JComboBox fonts=new JComboBox(arrfonts);
	JLabel lebsize=new JLabel("Size");
	String arrsize[]=new String[]{"8","14","18"};
	JComboBox size=new JComboBox(arrsize);
	JLabel lebstyle=new JLabel("Style");
	JCheckBox stylesbold=new JCheckBox("Bold");
	JCheckBox stylesitalic=new JCheckBox("Italic");
	JCheckBox stylesunderline=new JCheckBox("UnderLine");
	JTextField text=new JTextField();
	public void Frame()
	{
		frame.setVisible(true);
		frame.setBounds(500,200,340,270);
		ImageIcon icon=new ImageIcon("icon.PNG");
		frame.setIconImage(icon.getImage());
		frame.setTitle("Font Styles");
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		c.setLayout(null);
		c.setBackground(Color.gray);
	}
	public void window()
	{
		lebfont.setBounds(40,5,100,30);
		fonts.setBounds(40,40,100,30);
		
		lebsize.setBounds(40,85,100,30);
		size.setBounds(40,110,100,30);
		lebstyle.setBounds(200,5,100,30);
		stylesbold.setBounds(200,40,100,30);
		stylesitalic.setBounds(200,75,100,30);
		stylesunderline.setBounds(200,110,100,30);
		text.setBounds(40,155,260,40);
		
		
		lebfont.setFont(font);
		fonts.setFont(font);
		lebsize.setFont(font);
		size.setFont(font);
		lebstyle.setFont(font);
		stylesbold.setFont(font);
		stylesitalic.setFont(font);
		stylesunderline.setFont(font);
		
		
		
		c.add(lebfont);
		c.add(fonts);
		c.add(lebsize);
		c.add(size);
		c.add(lebstyle);
		c.add(stylesbold);
		c.add(stylesitalic);
		c.add(stylesunderline);
		c.add(text);
		c.revalidate();
	}
	public void opr()
	{
		fonts.addActionListener(new My());
		size.addActionListener(new My());
	}
	public class My implements ActionListener
	{
		//get Style
		public void actionPerformed(ActionEvent e)
		{
			if(e.getSource()==fonts||e.getSource()==size)
			{
				JComboBox fonts=(JComboBox)e.getSource();
				String msg=(String)fonts.getSelectedItem();
				JComboBox si=(JComboBox)e.getSource();
				String sizes=(String)si.getSelectedItem();
				if(msg=="Arial")
				{
					text.setText("arial if");		
				}
				else 
				{
					text.setText("arial else");
					switch(sizes)
					{
						case "8" :
							Font effect8=new Font("Arial",Font.BOLD,8);
							text.setFont(effect8);
							break;
						case "14" :
							Font effect14=new Font("Arial",Font.BOLD,14);
							text.setFont(effect14);
							break;						
						case "18" :
								Font effect18=new Font("Arial",Font.BOLD,18);
								text.setFont(effect18);
							break;
						default : text.setText("Default");
					}//arial end			
				}
				/*if(msg=="Algerian")
				{
					text.setText("Algerian if");		
				}
				else 
				{
					text.setText("Algerian else");
					if(sizes=="8")
					{
						Font effectal8=new Font("Algerian",Font.BOLD,8);
						text.setFont(effectal8);
					}
					else
					{
						
						if(sizes=="14")
						{
							Font effectal14=new Font("Algerian",Font.BOLD,14);
							text.setFont(effectal14);
						}
						else
						{
							if(sizes=="18")
							{
								Font effectal18=new Font("Algerian",Font.BOLD,18);
								text.setFont(effectal18);
							}
						}
					}//Algerian end				
				}*/
			}
			else
			{
				text.setText(" outer else");
			}
		}
	}
}

class FONTS
{
	public static void main(String args[])
	{
		FRAME obj=new FRAME();
		obj.Frame();
		obj.window();
		obj.opr();
	}
}
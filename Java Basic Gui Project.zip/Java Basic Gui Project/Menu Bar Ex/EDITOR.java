import java.awt.*;
import javax.swing.*;
class EDITOR
{
	public static void main(String args[])
	{
		JFrame frame=new JFrame("Chat Frame");
		JLabel label=new JLabel("Enter Text");
		JTextField text=new JTextField();
		JButton send=new JButton("Send");
		JButton reset=new JButton("Reset");
		frame.setBounds(450,150,400,380);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		MenuBar mb=new MenuBar();
		frame.setMenuBar(mb);
		Menu file=new Menu("File");
		mb.add(file);
		MenuItem open=new MenuItem("Open");
		file.add(open);
		MenuItem save=new MenuItem("Save as");
		file.add(save);
		Menu help=new Menu("Help");
		mb.add(help);
		
		Container c=frame.getContentPane();
		c.setLayout(null);
		JTextArea area=new JTextArea();
		area.setBounds(0,0,400,250);
		c.add(area);
		
		label.setBounds(50,250,60,20);
		c.add(label);
		
		text.setBounds(110,255,100,20);
		c.add(text);
		
		send.setBounds(220,255,70,20);
		c.add(send);
		
		reset.setBounds(300,255,70,20);
		c.add(reset);
		
	}
}
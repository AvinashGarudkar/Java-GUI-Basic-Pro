package Design;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.*;
public class Frame extends JFrame
{
	static JFrame frame=new JFrame();
	static Container c=frame.getContentPane();
	static JTextField screen=new JTextField();
	static Font font=new Font("Arial",Font.BOLD,30);
	static Font fonttext=new Font("Digital-7 Mono",Font.BOLD,35);

	static Color clrBG=new Color(48,48,54);
	static Color clrtext=new Color(255,255,255);
	static Color clrtexteql=new Color(0,255,128);
	static Color clrno=new Color(255,0,102);
	static Color clropr=new Color(77,121,255);	
	static Color clreql=new Color(0,255,128);

	static JButton b1=new JButton("1");
	static JButton b2=new JButton("2");
	static JButton b3=new JButton("3");
	static JButton bplus=new JButton("+");
	
	static JButton b4=new JButton("4");
	static JButton b5=new JButton("5");
	static JButton b6=new JButton("6");
	static JButton bmin=new JButton("-");
	
	static JButton b7=new JButton("7");
	static JButton b8=new JButton("8");
	static JButton b9=new JButton("9");
	static JButton bmul=new JButton("*");
	
	static JButton b0=new JButton("0");
	static JButton bdot=new JButton(".");
	static JButton beql=new JButton("=");
	static JButton bdiv=new JButton("/");
	static String bs1;
	static String bs2;
	int btn1;
	int btn2;
	static int ans;
	public void frame()
	{
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(450,100,410,390);
		frame.setTitle("Simple Calculator");
	}
	public void contener()
	{
		c.setLayout(null);
		c.setBackground(clrBG);
		
		screen.setBounds(50,20,300,40);
		screen.setFont(fonttext);
		c.add(screen);
		
		b1.setBounds(50,80,60,40);
		b1.setFont(font);
		b1.setBackground(clrno);
		b1.setForeground(clrtext);
		c.add(b1);
		
		b2.setBounds(130,80,60,40);
		b2.setFont(font);
		b2.setBackground(clrno);
		b2.setForeground(clrtext);
		c.add(b2);
		
		b3.setBounds(210,80,60,40);
		b3.setFont(font);
		b3.setBackground(clrno);		
		b3.setForeground(clrtext);
		c.add(b3);
		
		bplus.setBounds(290,80,60,40);
		bplus.setFont(font);
		bplus.setBackground(clropr);
		bplus.setForeground(clrtext);
		c.add(bplus);

		b4.setBounds(50,140,60,40);
		b4.setFont(font);
		b4.setBackground(clrno);
		b4.setForeground(clrtext);
		c.add(b4);
		
		b5.setBounds(130,140,60,40);
		b5.setFont(font);
		b5.setBackground(clrno);
		b5.setForeground(clrtext);
		c.add(b5);
		
		b6.setBounds(210,140,60,40);
		b6.setFont(font);
		b6.setBackground(clrno);	
		b6.setForeground(clrtext);
		c.add(b6);
		
		bmin.setBounds(290,140,60,40);
		bmin.setFont(font);
		bmin.setBackground(clropr);
		bmin.setForeground(clrtext);
		c.add(bmin);
		
		b7.setBounds(50,200,60,40);
		b7.setFont(font);
		b7.setBackground(clrno);
		b7.setForeground(clrtext);
		c.add(b7);
		
		b8.setBounds(130,200,60,40);
		b8.setFont(font);
		b8.setBackground(clrno);
		b8.setForeground(clrtext);
		c.add(b8);
		
		b9.setBounds(210,200,60,40);
		b9.setFont(font);
		b9.setBackground(clrno);		
		b9.setForeground(clrtext);
		c.add(b9);
		
		bmul.setBounds(290,200,60,40);
		bmul.setFont(font);
		bmul.setBackground(clropr);
		bmul.setForeground(clrtext);
		c.add(bmul);

		bdot.setBounds(50,260,60,40);
		bdot.setFont(font);
		bdot.setBackground(clreql);
		bdot.setForeground(clrtext);
		c.add(bdot);		
		
		b0.setBounds(130,260,60,40);
		b0.setFont(font);
		b0.setBackground(clrno);
		b0.setForeground(clrtext);
		c.add(b0);
		
		beql.setBounds(210,260,60,40);
		beql.setFont(font);
		beql.setBackground(clreql);	
		beql.setForeground(clrtext);
		c.add(beql);
		
		bdiv.setBounds(290,260,60,40);
		bdiv.setFont(font);
		bdiv.setBackground(clropr);
		bdiv.setForeground(clrtext);
		c.add(bdiv);		
	}
	public void opr()
	{
		b1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent b)
			{
				bs1="1";
				screen.setText(bs1);
			}
		});
		b2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent b2a)
			{
				bs2="2";
				screen.setText(bs1+"+"+bs2);
			}
		});
		bplus.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				screen.setText(bs1+"+");
				
			}
		});
		beql.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent eqla)
			{	
				btn1=Integer.parseInt(bs1);
				btn2=Integer.parseInt(bs2);
				ans=btn1+btn2;
				screen.setText(btn1+"+"+btn2+"="+ans);
			}
		});
	}
}
import Design.Frame;
class CALC
{
	public static void main(String args[])
	{
		Frame objframe=new Frame();
		objframe.frame();
		objframe.contener();
		objframe.opr();
	}
}